Distributed by: EkoZero7

By installing or using this font, you are agree to the Product Usage Agreement:

1. This font for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
2. You are requires a license for PROMOTIONAL or COMMERCIAL use.
3. CONTACT ME before any Promotional or Commercial Use!(ekocahyanto07@gmail.com)

LINK TO PURCHASE COMMERSIAL LICENSE:

ekocahyanto07@gmail.com



to DONATE click here:

https://paypal.me/ahmadwakhid1


Thanks,
EkoZero7

